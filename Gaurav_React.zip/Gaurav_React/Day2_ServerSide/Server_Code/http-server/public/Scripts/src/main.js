var Result = React.createClass({
    render: function(){
        return <h2>Result: {this.props.rCount}</h2>;
    }
});

var Button = React.createClass({
    localClick:function(){
        this.props.handleClick(this.props.incBy);
    },
    render: function(){
        return <button onClick={this.localClick}>Inc {this.props.incBy}</button>
    }
});

var Main = React.createClass({
    getInitialState:function(){
        return {count:0}
    },
    changeCounter:function(by){
        this.setState({count:this.state.count+by});
    },
    render: function(){
        return (
            <div>
                <Result rCount={this.state.count}/>
                <Button incBy={5} handleClick={this.changeCounter}/>
                <Button incBy={10} handleClick={this.changeCounter}/>
                <Button incBy={15} handleClick={this.changeCounter}/>
                <Button incBy={20} handleClick={this.changeCounter}/>
            </div>
        );
    }
});

ReactDOM.render(<Main />, document.getElementById("container"));
