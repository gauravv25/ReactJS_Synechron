var Result = React.createClass({
    displayName: "Result",

    render: function () {
        return React.createElement(
            "h2",
            null,
            "Result: ",
            this.props.rCount
        );
    }
});

var Button = React.createClass({
    displayName: "Button",

    localClick: function () {
        this.props.handleClick(this.props.incBy);
    },
    render: function () {
        return React.createElement(
            "button",
            { onClick: this.localClick },
            "Inc ",
            this.props.incBy
        );
    }
});

var Main = React.createClass({
    displayName: "Main",

    getInitialState: function () {
        return { count: 0 };
    },
    changeCounter: function (by) {
        this.setState({ count: this.state.count + by });
    },
    render: function () {
        return React.createElement(
            "div",
            null,
            React.createElement(Result, { rCount: this.state.count }),
            React.createElement(Button, { incBy: 5, handleClick: this.changeCounter }),
            React.createElement(Button, { incBy: 10, handleClick: this.changeCounter }),
            React.createElement(Button, { incBy: 15, handleClick: this.changeCounter }),
            React.createElement(Button, { incBy: 20, handleClick: this.changeCounter })
        );
    }
});

ReactDOM.render(React.createElement(Main, null), document.getElementById("container"));
